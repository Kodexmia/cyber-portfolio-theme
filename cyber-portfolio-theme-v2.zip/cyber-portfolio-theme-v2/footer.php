  <footer>
    &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> &middot; <?php bloginfo('description'); ?>
  </footer>
</div><!-- .page-wrap -->

<?php wp_footer(); ?>
</body>
</html>
